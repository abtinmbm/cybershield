ckeditor-light-theme
====================
